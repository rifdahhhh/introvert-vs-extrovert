import os
from tfx.components import (
    CsvExampleGen, StatisticsGen, SchemaGen, ExampleValidator,
    Transform, Trainer, Tuner, Evaluator, Pusher
)
from tfx.proto import example_gen_pb2, trainer_pb2, pusher_pb2
from tfx.dsl.components.common.resolver import Resolver
from tfx.dsl.input_resolution.strategies.latest_blessed_model_strategy import LatestBlessedModelStrategy
from tfx.types import Channel
from tfx.types.standard_artifacts import Model, ModelBlessing
import tensorflow_model_analysis as tfma

def init_components(args):
    component_list = []

    # 1. ExampleGen
    example_gen = CsvExampleGen(
        input_base=args["data_dir"],
        output_config=example_gen_pb2.Output(
            split_config=example_gen_pb2.SplitConfig(splits=[
                example_gen_pb2.SplitConfig.Split(name="train", hash_buckets=7),
                example_gen_pb2.SplitConfig.Split(name="eval", hash_buckets=3),
            ])
        )
    )
    component_list.append(example_gen)

    # 2. StatisticsGen
    statistics_gen = StatisticsGen(examples=example_gen.outputs["examples"])
    component_list.append(statistics_gen)

    # 3. SchemaGen
    schema_gen = SchemaGen(statistics=statistics_gen.outputs["statistics"])
    component_list.append(schema_gen)

    # 4. ExampleValidator
    example_validator = ExampleValidator(
        statistics=statistics_gen.outputs["statistics"],
        schema=schema_gen.outputs["schema"]
    )
    component_list.append(example_validator)

    # 5. Transform
    transform = Transform(
        examples=example_gen.outputs['examples'],
        schema=schema_gen.outputs['schema'],
        module_file=os.path.abspath(args["transform_module"])
    )
    component_list.append(transform)

    # 6. Tuner
    tuner = Tuner(
        module_file=os.path.abspath(args["tuner_module"]),
        examples=transform.outputs['transformed_examples'],
        transform_graph=transform.outputs['transform_graph'],
        train_args=trainer_pb2.TrainArgs(num_steps=args["train_steps"]),
        eval_args=trainer_pb2.EvalArgs(num_steps=args["eval_steps"])
    )
    component_list.append(tuner)

    # 7. Trainer
    trainer = Trainer(
        module_file=os.path.abspath(args["trainer_module"]),
        examples=transform.outputs['transformed_examples'],
        transform_graph=transform.outputs['transform_graph'],
        schema=schema_gen.outputs['schema'],
        train_args=trainer_pb2.TrainArgs(num_steps=args["train_steps"]),
        eval_args=trainer_pb2.EvalArgs(num_steps=args["eval_steps"]),
        hyperparameters=tuner.outputs['best_hyperparameters']
    )
    component_list.append(trainer)

    # 8. Evaluator
    eval_config = tfma.EvalConfig(
        model_specs=[tfma.ModelSpec(label_key='Personality_xf')],
        slicing_specs=[tfma.SlicingSpec()],
        metrics_specs=[
            tfma.MetricsSpec(
                metrics=[tfma.MetricConfig(class_name='BinaryAccuracy')],
                thresholds={
                    'binary_accuracy': tfma.MetricThreshold(
                        value_threshold=tfma.GenericValueThreshold(
                            lower_bound={'value': 0.6}
                        )
                    )
                }
            )
        ]
    )
    evaluator = Evaluator(
        examples=transform.outputs['transformed_examples'],
        model=trainer.outputs['model'],
        eval_config=eval_config
    )
    component_list.append(evaluator)

    # 9. Model Resolver (opsional, skip on first run if needed)
    model_resolver = Resolver(
        strategy_class=LatestBlessedModelStrategy,
        model=Channel(type=Model),
        model_blessing=Channel(type=ModelBlessing)
    ).with_id('latest_blessed_model_resolver')
    component_list.append(model_resolver)

    # 10. Pusher
    pusher = Pusher(
        model=trainer.outputs['model'],
        model_blessing=evaluator.outputs['blessing'],
        push_destination=pusher_pb2.PushDestination(
            filesystem=pusher_pb2.PushDestination.Filesystem(
                base_directory=os.path.abspath(args["serving_model_dir"])
            )
        )
    )
    component_list.append(pusher)

    return component_list
